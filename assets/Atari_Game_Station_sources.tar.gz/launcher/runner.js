// Atari800 browser host; the emulator owns emulated machine state.
const canvas = document.querySelector('canvas');
const boot = parent.currentBoot;
const media=boot.game.media[boot.media],filename='/game'+media.ext;
const diskImages=[media,...(media.extraDisks||[])];
let ready = false, stateBusy = false, autoTapePending=true, activeDisk=0, presses = new Set();
const nap = ms => new Promise(r => setTimeout(r, ms));
// Chromium may defer a suspended emulator's short timer during touch input.
// Race that timer against a deadline check on the visible parent's animation
// frame. Only one path resumes Asyncify, and neither wakes it before its due time.
function frameSleep(resolve,ms){
  const delay=Math.max(0,Number(ms)||0),due=performance.now()+delay;
  let finished=false,timer=0,raf=0;
  const done=()=>{if(finished)return;finished=true;clearTimeout(timer);if(raf)parent.cancelAnimationFrame(raf);resolve();};
  const watch=()=>{if(finished||document.hidden)return;if(performance.now()>=due)done();else raf=parent.requestAnimationFrame(watch);};
  timer=setTimeout(done,delay);
  if(!document.hidden)raf=parent.requestAnimationFrame(watch);
}
function resumeAudio(){
  const c=window.Module?.SDL2?.audioContext;
  if(parent.muted||!c||!['suspended','interrupted'].includes(c.state))return;
  // A blocked autoplay promise must not prevent a later real user gesture.
  try{Promise.resolve(c.resume()).catch(()=>{});}catch{}
}
const keySpec = {
  up:['8','Numpad8',104,3], down:['5','Numpad5',101,3],
  left:['4','Numpad4',100,3], right:['6','Numpad6',102,3],
  fire:['Control','ControlRight',17,2], start:['F4','F4',115,0],
  select:['F3','F3',114,0], option:['F2','F2',113,0],
  space:[' ','Space',32,0], enter:['Enter','Enter',13,0],
  escape:['Escape','Escape',27,0], break:['F7','F7',118,0],
  reset:['F5','F5',116,0], turbo:['F12','F12',123,0],
  menu:['F1','F1',112,0], shift:['Shift','ShiftLeft',16,1],
  control:['Control','ControlLeft',17,1], backspace:['Backspace','Backspace',8,0],
  cursorup:['ArrowUp','ArrowUp',38,0], cursordown:['ArrowDown','ArrowDown',40,0],
  cursorleft:['ArrowLeft','ArrowLeft',37,0], cursorright:['ArrowRight','ArrowRight',39,0]
};
function emit(id,down) {
  if(!ready) return;
  let spec=keySpec[id];
  if(!spec && /^[a-z0-9]$/i.test(id)) spec=[id.toLowerCase(),/^\d$/.test(id)?'Digit'+id:'Key'+id.toUpperCase(),id.toUpperCase().charCodeAt(0),0];
  if(!spec) return;
  if(down === presses.has(id)) return;
  if(down) presses.add(id); else presses.delete(id);
  const e=new KeyboardEvent(down?'keydown':'keyup',{key:spec[0],code:spec[1],keyCode:spec[2],which:spec[2],location:spec[3],bubbles:true,cancelable:true,shiftKey:presses.has('shift'),ctrlKey:presses.has('control')||presses.has('fire')});
  canvas.dispatchEvent(e);
  // SDL2 receives printable Atari keys through its text-input/keypress path.
  // Joystick keypad events must never generate text (some games pause on it).
  if(down&&/^[a-z0-9]$/i.test(id)&&!presses.has('control')&&!presses.has('fire')){
    const char=presses.has('shift')?id.toUpperCase():id.toLowerCase(),n=char.charCodeAt(0);
    canvas.dispatchEvent(new KeyboardEvent('keypress',{key:char,code:spec[1],keyCode:n,which:n,charCode:n,bubbles:true,cancelable:true,shiftKey:presses.has('shift')}));
  }
}
function release(){for(const id of [...presses])emit(id,false);}
async function pulse(id){emit(id,true);await nap(100);emit(id,false);}
function writeMainDisk(index){
  if(!Number.isInteger(index)||!diskImages[index])throw Error('Neplatná disketa.');
  const bytes=parent.unbase64(diskImages[index].data);
  Module.FS.writeFile(filename,bytes);
  Module.FS.writeFile('/ame'+media.ext,bytes);
  Module.FS.writeFile('/home/web_user/ame'+media.ext,bytes);
  activeDisk=index;
}
async function state(load,diskIndex=activeDisk) {
  if(!ready)throw Error('Emulátor ešte nie je pripravený.');
  if(stateBusy)throw Error('Prebieha ukladanie alebo načítanie.');
  stateBusy=true; release();
  try {
    if(load){autoTapePending=false;if(diskIndex!==activeDisk)writeMainDisk(diskIndex);Module.FS.writeFile('/gx-state.a8s',load);Module._gx_request_load();}
    else Module._gx_request_save();
    const deadline=Date.now()+12000;
    while(Module._gx_state_status()===0){if(Date.now()>deadline)throw Error('Emulátor neodpovedal. Zatvor jeho menu a skús to znova.');await nap(20);}
    if(Module._gx_state_status()!==1)throw Error('Pozíciu sa nepodarilo spracovať.');
    return load?true:Module.FS.readFile('/gx-state.a8s').slice();
  }finally{stateBusy=false;}
}
window.runner={emit,release,pulse,save:()=>state(),load:(b,diskIndex=0)=>state(b,diskIndex),getDisk:()=>activeDisk,
  async swapDisk(index){const bytes=await state();await state(bytes,index);},get ready(){return ready;},
  mute(v){const c=window.Module?.SDL2?.audioContext;if(v&&c?.state==='running')c.suspend().catch(()=>{});else if(!v)resumeAudio();},
  resumeAudio,
  shot(){try{return canvas.toDataURL('image/png');}catch{return null;}}
};
window.addEventListener('blur',release);
window.addEventListener('keydown',e=>{if(e.isTrusted)parent.physicalKey(e,true);},true);
window.addEventListener('keyup',e=>{if(e.isTrusted)parent.physicalKey(e,false);},true);
(async()=>{
  try{
    const wasm=await parent.asset('core-wasm');
    let js=new TextDecoder().decode(await parent.asset('core-js'));
    const sleepHook='let innerFunc = () => new Promise((resolve) => setTimeout(resolve, ms));';
    if(!js.includes(sleepHook))throw Error('Nekompatibilná verzia časovania emulátora.');
    js=js.replace(sleepHook,"let innerFunc = () => new Promise((resolve) => Module['frameSleep'](resolve, ms));");
    const bios=JSON.parse(new TextDecoder().decode(await parent.asset('bios')));
    const args=['-xl','-pal','-nobasic','-xlxe_rom','/atarixl.rom','-basic_rom','/ataribas.rom','-osb_rom','/atariosb.rom','-windowed','-win-width','384','-win-height','288','-stretch','full','-fit-screen','both','-image-aspect','none','-horiz-area','tv','-vert-area','tv','-sound','-audio16','-dsprate','44100'];
    if(boot.game.machine==='800')args[0]='-atari';
    if(boot.game.flags)args.push(...boot.game.flags);
    if(media.flags)args.push(...media.flags);
    if(media.ext==='.bas')args[2]='-basic';
    if(!boot.restoreAtBoot){
    if(media.ext==='.rom'||media.ext==='.car'){
      const bytes=parent.unbase64(media.data);
      if(new TextDecoder().decode(bytes.subarray(0,4))!=='CART')args.push('-cart-type',String(media.cartType||(bytes.length===8192?1:2)));
      args.push('-cart',filename);
    }
    else if(media.ext==='.cas')args.push('-boottape',filename,'-tape-readonly');
    else if(['.com','.xex','.bas'].includes(media.ext))args.push('-run',filename);
    else args.push(filename);
    for(let i=0;i<(media.extraDisks||[]).length;i++)args.push('/disk'+(i+2)+media.extraDisks[i].ext);
    }
    window.Module={canvas,arguments:args,wasmBinary:wasm,frameSleep,
      preRun:[()=>{
        for(const[name,data]of Object.entries(bios))Module.FS.writeFile('/'+name,parent.unbase64(data));
        const bytes=parent.unbase64(media.data);
        Module.FS.writeFile(filename,bytes);
        // Atari800 5.2 strips two leading characters when cwd is '/'.
        // Retain aliases for initial snapshots created before cwd was fixed.
        Module.FS.writeFile('/ame'+media.ext,bytes);
        Module.FS.writeFile('/home/web_user/ame'+media.ext,bytes);
        Module.FS.chdir('/home/web_user');
        for(let i=0;i<(media.extraDisks||[]).length;i++)Module.FS.writeFile('/disk'+(i+2)+media.extraDisks[i].ext,parent.unbase64(media.extraDisks[i].data));
      }],
      print:t=>parent.emuLog(boot.token,t),printErr:t=>parent.emuLog(boot.token,t),
      onAbort:e=>parent.emuFailed(boot.token,String(e)),
      onExit:code=>{ready=false;parent.emuFailed(boot.token,'Emulátor sa ukončil ('+code+').');},
      onRuntimeInitialized:()=>setTimeout(async()=>{
        ready=true;parent.emuReady(boot.token);
        if(media.ext==='.cas'){await nap(700);if(autoTapePending)await pulse('enter');}
      },100)
    };
    const tag=document.createElement('script');tag.textContent=js;document.body.append(tag);
  }catch(e){parent.emuFailed(boot.token,e.message);}
})();
