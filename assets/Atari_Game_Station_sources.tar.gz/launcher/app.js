'use strict';
const $=id=>document.getElementById(id);
function unbase64(s){const raw=atob(s.trim()),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
function base64(bytes){let s='';for(let i=0;i<bytes.length;i+=16384)s+=String.fromCharCode(...bytes.subarray(i,i+16384));return btoa(s);}
const assetCache=new Map();
async function asset(id){if(!assetCache.has(id))assetCache.set(id,(async()=>{const bytes=unbase64($('asset-'+id).textContent);if($('asset-'+id).dataset.gzip==='1'){if(!window.DecompressionStream)throw Error('Tento prehliadač nepodporuje rozbalenie dát. Použi aktuálny Chrome, Edge alebo Safari.');return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());}return bytes;})());return assetCache.get(id);}
const GAMES=JSON.parse($('game-data').textContent);
let currentBoot=null,muted=false,ready=false,busy=false,starting=false,generation=0,turbo=false,logs=[],toastTimer;
Object.defineProperty(window,'currentBoot',{get:()=>currentBoot});
Object.defineProperty(window,'muted',{get:()=>muted});
const inputSources=new Map(),physicalHeld=new Map();
let autoFireOn=false,autoFireFrame=0,autoFireStart=0;
function runner(){return $('emulator').contentWindow?.runner;}
function scaleEmulator(){const f=$('emulator');f.style.width='384px';f.style.height='288px';f.style.transformOrigin='0 0';f.style.transform='scale('+($('screen').clientWidth/384)+','+($('screen').clientHeight/288)+')';}
new ResizeObserver(scaleEmulator).observe($('screen'));
function note(msg,error=false){$('toast').textContent=msg;$('toast').classList.toggle('error',error);$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,error?6500:3500);}
function status(s){$('status').textContent=s;}
function emuLog(token,t){if(token!==generation)return;logs.push(String(t));logs=logs.slice(-70);$('logs').textContent=logs.join('\n');}
function emuFailed(token,t){if(token!==generation)return;ready=false;status('Chyba spustenia: '+t);note('Hru sa nepodarilo spustiť. Podrobnosti sú v Návode.',true);refreshButtons();}
function emuReady(token){if(token!==generation)return;ready=true;$('cover').hidden=true;const b=currentBoot;status(b.game.title+' · '+(b.game.media[b.media].ext==='.cas'?'Nahráva sa kazeta; počkaj na hernú obrazovku.':'Spustené. Hru začni tlačidlom START alebo FIRE.'));refreshButtons();refreshSlot();}
function setInput(id,source,down){let set=inputSources.get(id);if(!set)inputSources.set(id,set=new Set());const before=set.size>0;if(down)set.add(source);else set.delete(source);const after=set.size>0;if(before!==after)runner()?.emit(id,after);}
function paintAutoFire(){const b=$('auto-fire');if(!b)return;b.innerHTML='AUTO FIRE<small>'+(autoFireOn?'Zapnuté':'Vypnuté')+'</small>';b.classList.toggle('active',autoFireOn);b.setAttribute('aria-pressed',String(autoFireOn));b.disabled=!ready||busy||starting;}
function stopAutoFire(){autoFireOn=false;cancelAnimationFrame(autoFireFrame);autoFireFrame=0;setInput('fire','auto-fire',false);paintAutoFire();}
function autoFireTick(now){if(!autoFireOn)return;if(!ready||busy||starting||document.hidden){stopAutoFire();return;}setInput('fire','auto-fire',Math.floor((now-autoFireStart)/62.5)%2===0);autoFireFrame=requestAnimationFrame(autoFireTick);}
function toggleAutoFire(){if(!ready||busy||starting)return;if(autoFireOn){stopAutoFire();return;}autoFireOn=true;autoFireStart=performance.now();setInput('fire','auto-fire',true);autoFireFrame=requestAnimationFrame(autoFireTick);paintAutoFire();runner()?.resumeAudio();}
function releaseAll(){stopAutoFire();inputSources.clear();physicalHeld.clear();runner()?.release();document.querySelectorAll('.held').forEach(x=>x.classList.remove('held'));$('knob').style.transform='';joyPointer=null;dpadPointers.clear();}
const physicalMap={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',KeyW:'up',KeyS:'down',KeyA:'left',KeyD:'right',ControlLeft:'fire',ControlRight:'fire',KeyZ:'fire',Space:'space',Enter:'enter',Escape:'escape',F2:'option',F3:'select',F4:'start',F7:'break'};
function physicalKey(e,down){if(!ready||starting||e.metaKey||e.altKey)return;if(e.ctrlKey&&!['ControlLeft','ControlRight'].includes(e.code)&&!physicalHeld.has('ControlLeft')&&!physicalHeld.has('ControlRight'))return;if(e.target?.matches?.('select,input,textarea'))return;const id=physicalMap[e.code];if(!id)return;e.preventDefault();e.stopImmediatePropagation();if(down)physicalHeld.set(e.code,id);else physicalHeld.delete(e.code);setInput(id,'pc:'+e.code,down);if(down)runner()?.resumeAudio();}
window.addEventListener('keydown',e=>physicalKey(e,true),true);window.addEventListener('keyup',e=>physicalKey(e,false),true);window.addEventListener('blur',releaseAll);document.addEventListener('visibilitychange',()=>{if(document.hidden)releaseAll();});
function bindKey(button){button.addEventListener('pointerdown',e=>{e.preventDefault();if(!ready||starting)return;const id=button.dataset.key;if(button.classList.contains('toggle')){const down=!button.classList.contains('held');button.classList.toggle('held',down);setInput(id,'toggle:'+id,down);runner()?.resumeAudio();return;}button.setPointerCapture(e.pointerId);button.classList.add('held');setInput(id,'touch:'+e.pointerId,true);runner()?.resumeAudio();});const up=e=>{if(button.classList.contains('toggle'))return;button.classList.remove('held');setInput(button.dataset.key,'touch:'+e.pointerId,false);};button.addEventListener('pointerup',up);button.addEventListener('pointercancel',up);button.addEventListener('lostpointercapture',up);button.addEventListener('contextmenu',e=>e.preventDefault());}
const controlProfiles={
  'Silent_Service_MicroProse_Software_USA':[['fire','FIRE','Akcia / potvrdiť'],['1','1','Voľba 1'],['2','2','Voľba 2'],['3','3','Voľba 3'],['start','START','Pokračovať'],['option','OPTION','Voľba'],['enter','RETURN','Potvrdiť']],
  'Grand_Prix_Simulator':[['fire','FIRE','Akcia'],['1','1','Voľba 1'],['2','2','Voľba 2'],['start','START','F4'],['select','SELECT','F3'],['space','SPACE','Medzerník'],['escape','ESC','Späť']],
  'One_on_One_Compute!':[['fire','FIRE','Akcia'],['1','1','Joystick'],['2','2','Paddle'],['enter','RETURN','Potvrdiť'],['start','START','F4'],['space','SPACE','Medzerník'],['escape','ESC','Späť']],
  'Strip_Poker':[['fire','FIRE','Potvrdiť'],['1','1','Voľba 1'],['2','2','Voľba 2'],['4','4','Ďalšie'],['enter','RETURN','Potvrdiť'],['space','SPACE','Medzerník'],['escape','ESC','Späť']],
  'default':[['fire','FIRE','Akcia / streľba'],['start','START','F4'],['select','SELECT','F3'],['option','OPTION','F2'],['space','SPACE','Medzerník'],['enter','RETURN','Enter'],['escape','ESC','Späť']]
};
function renderKeys(game){$('actions').replaceChildren();for(const [key,label,sub]of(controlProfiles[game?.id]||controlProfiles.default)){const b=document.createElement('button');b.dataset.key=key;b.innerHTML=label+'<small>'+sub+'</small>';if(key==='fire')b.classList.add('fire');bindKey(b);$('actions').append(b);}const auto=document.createElement('button');auto.id='auto-fire';auto.className='auto-fire';auto.onclick=toggleAutoFire;$('actions').append(auto);paintAutoFire();}
let joyPointer=null;
const ANALOG_SENSITIVITY=.9;
function joyMove(e){if(e.pointerId!==joyPointer)return;const r=$('joystick').getBoundingClientRect(),radius=r.width*.34;let x=(e.clientX-r.left-r.width/2)/radius*ANALOG_SENSITIVITY,y=(e.clientY-r.top-r.height/2)/radius*ANALOG_SENSITIVITY;const mag=Math.hypot(x,y);if(mag>1){x/=mag;y/=mag;}$('knob').style.transform=`translate(${x*radius*.65}px,${y*radius*.65}px)`;const active=mag>.22;setInput('left','joy',active&&x<-.33);setInput('right','joy',active&&x>.33);setInput('up','joy',active&&y<-.33);setInput('down','joy',active&&y>.33);}
$('joystick').addEventListener('pointerdown',e=>{e.preventDefault();if(joyPointer!==null||!ready||starting)return;joyPointer=e.pointerId;$('joystick').setPointerCapture(e.pointerId);joyMove(e);runner()?.resumeAudio();});$('joystick').addEventListener('pointermove',joyMove);function joyUp(e){if(e.pointerId!==joyPointer)return;joyPointer=null;for(const id of['up','down','left','right'])setInput(id,'joy',false);$('knob').style.transform='';}for(const t of['pointerup','pointercancel','lostpointercapture'])$('joystick').addEventListener(t,joyUp);
const dpadPointers=new Map(),directions=['up','down','left','right'];
function paintDpad(){const active=new Set([...dpadPointers.values()].flat());for(const b of $('dpad').querySelectorAll('[data-directions]')){const keys=b.dataset.directions.split(' ');b.classList.toggle('held',keys.every(k=>active.has(k)));}}
function dpadMove(e){if(!dpadPointers.has(e.pointerId))return;const r=$('dpad').getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;let keys=[];if(x>=0&&x<1&&y>=0&&y<1){if(x<1/3)keys.push('left');else if(x>=2/3)keys.push('right');if(y<1/3)keys.push('up');else if(y>=2/3)keys.push('down');}dpadPointers.set(e.pointerId,keys);for(const id of directions)setInput(id,'dpad:'+e.pointerId,keys.includes(id));paintDpad();}
$('dpad').addEventListener('pointerdown',e=>{e.preventDefault();if(!ready||starting)return;dpadPointers.set(e.pointerId,[]);$('dpad').setPointerCapture(e.pointerId);dpadMove(e);runner()?.resumeAudio();});$('dpad').addEventListener('pointermove',dpadMove);
function dpadUp(e){if(!dpadPointers.delete(e.pointerId))return;for(const id of directions)setInput(id,'dpad:'+e.pointerId,false);paintDpad();}
for(const t of['pointerup','pointercancel','lostpointercapture'])$('dpad').addEventListener(t,dpadUp);
$('dpad').addEventListener('contextmenu',e=>e.preventDefault());
let controlMode='analog';try{if(localStorage.getItem('atari-control-mode')==='dpad')controlMode='dpad';}catch{}
function renderControlMode(){$('joystick').hidden=controlMode!=='analog';$('dpad').hidden=controlMode!=='dpad';$('control-mode').textContent=controlMode==='analog'?'Analóg':'D-pad';$('control-mode').setAttribute('aria-label',controlMode==='analog'?'Ovládanie: Analóg. Prepnúť na D-pad.':'Ovládanie: D-pad. Prepnúť na Analóg.');$('control-title').textContent=(controlMode==='analog'?'JOYSTICK':'D-PAD')+' · 8 SMEROV';}
$('control-mode').onclick=()=>{releaseAll();controlMode=controlMode==='analog'?'dpad':'analog';renderControlMode();try{localStorage.setItem('atari-control-mode',controlMode);}catch{}};
renderControlMode();
for(const g of GAMES){const o=document.createElement('option');o.value=g.id;o.textContent=g.title;$('games').append(o);}
$('games').value=GAMES.find(g=>g.id==='Bruce_Lee').id;
function selected(){return GAMES.find(g=>g.id===$('games').value);}
function updateMedia(){const g=selected();$('media').replaceChildren();g.media.forEach((m,i)=>{const o=document.createElement('option');o.value=i;o.textContent=m.name+(m.unavailable?' · nespustiteľná samostatne':'');o.disabled=!!m.unavailable;$('media').append(o);});$('media').hidden=g.media.length===1;}
updateMedia();$('games').addEventListener('change',()=>{updateMedia();if(!ready)renderKeys(selected());});
function refreshButtons(){const locked=busy||starting;for(const id of['save','export'])$(id).disabled=!ready||locked;$('load').disabled=!ready||locked;$('launch').disabled=locked;$('cover-start').disabled=locked;$('games').disabled=locked;$('media').disabled=locked;$('slot').disabled=locked;$('import').disabled=locked;$('disk-select').disabled=locked||!ready;paintAutoFire();}
async function bootGame(g=selected(),mi=Number($('media').value||0),stateBytes=null,useQuick=false,stateDisk=0){
  // Slot restore holds the operation lock while replacing the old machine.
  if(busy&&!stateBytes)throw Error('Počkaj na dokončenie aktuálnej operácie.');
  if(g.media[mi]?.unavailable)throw Error('Táto strana sa samostatne nespustí. Vyber stranu A; pôvodné dáta sú zachované.');
  releaseAll();ready=false;generation++;turbo=false;$('turbo').textContent='Turbo: vyp.';logs=[];currentBoot={game:g,media:mi,token:generation,restoreAtBoot:!!stateBytes||(useQuick&&!!g.media[mi].boot)};const token=generation;
  $('games').value=g.id;updateMedia();$('media').value=String(mi);renderKeys(g);updateDiskSelector(g.media[mi]);$('now-playing').textContent=g.title;$('format-label').textContent=g.media[mi].ext.slice(1).toUpperCase()+' · PAL';
  $('cover').hidden=true;status('Pripravujem '+g.title+'…');refreshButtons();refreshSlot();
  const rjs=new TextDecoder().decode(await asset('runner'));
  if(token!==generation)return;
  const doc='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}canvas{display:block;position:absolute;inset:0;width:100%!important;height:100%!important;image-rendering:pixelated;outline:0}</style><canvas id="canvas" width="384" height="288" tabindex="0"></canvas><script>'+rjs.replace(/<\/script/gi,'<\\/script')+'<\/script>';
  const old=$('emulator'),frame=document.createElement('iframe');frame.id='emulator';frame.title='Herná obrazovka Atari';frame.allow='autoplay; fullscreen';old.replaceWith(frame);scaleEmulator();frame.srcdoc=doc;
  const deadline=Date.now()+25000;while(!ready){if(token!==generation)throw Error('Spustenie bolo nahradené.');if(Date.now()>deadline)throw Error('Spustenie trvá príliš dlho. Pozri diagnostiku v Návode.');await new Promise(r=>setTimeout(r,40));}
  let initialQuick=false;if(!stateBytes&&useQuick&&g.media[mi].boot){initialQuick=true;const compressed=unbase64(g.media[mi].boot);stateBytes=new Uint8Array(await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());}
  if(stateBytes){await runner().load(stateBytes,stateDisk);$('disk-select').value=String(stateDisk);status('Pripravené · '+g.title+' · START alebo FIRE spustí hru.');}
  if(initialQuick)for(const key of(g.media[mi].bootKeys||[]))await runner().pulse(key);
  runner()?.mute(muted);
}
async function launch(...args){if(starting)throw Error('Hra sa ešte pripravuje.');starting=true;refreshButtons();try{return await bootGame(...args);}finally{starting=false;refreshButtons();refreshSlot();}}
function start(){if(fullscreenOnStart){fullscreenOnStart=false;enterFullscreen(true);}launch().catch(e=>note(e.message,true));}$('launch').onclick=start;$('cover-start').onclick=start;
let dbPromise;
function db(){if(!dbPromise)dbPromise=new Promise((resolve,reject)=>{const request=indexedDB.open('atari-game-station-v1',1);request.onupgradeneeded=()=>request.result.createObjectStore('states',{keyPath:'key'});request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(Error('Prehliadač nepovolil trvalé ukladanie. Použi Export pozície.'));});return dbPromise;}
async function recordGet(key){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('states','readonly'),r=t.objectStore('states').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function recordPut(rec){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('states','readwrite');t.objectStore('states').put(rec);t.oncomplete=()=>resolve();t.onerror=()=>reject(Error('Pozíciu sa nepodarilo uložiť. Použi Export pozície.'));t.onabort=()=>reject(Error('Ukladanie bolo prerušené.'));});}
function slotKey(){if(!currentBoot)return null;return currentBoot.game.id+':'+currentBoot.game.media[currentBoot.media].hash+':'+$('slot').value;}
async function refreshSlot(){const key=slotKey();if(!key){$('load').disabled=true;return;}try{const r=await recordGet(key);if(key!==slotKey())return;$('load').disabled=!ready||busy||starting||!r;$('saved-info').textContent=currentBoot.game.title+' · Slot '+$('slot').value+' · '+(r?'Uložené '+new Date(r.created).toLocaleString('sk-SK'):'Prázdny slot')+' · Exportuj pozíciu pre zálohu mimo prehliadača.';}catch(e){$('saved-info').textContent=e.message;$('load').disabled=true;}}
$('slot').onchange=refreshSlot;
async function operation(fn){if(busy)return;busy=true;refreshButtons();releaseAll();try{await fn();}catch(e){note(e.message,true);}finally{busy=false;refreshButtons();refreshSlot();}}
$('save').onclick=()=>operation(async()=>{const key=slotKey(),b=currentBoot,bytes=await runner().save();await recordPut({key,created:Date.now(),game:b.game.id,media:b.media,bytes,disk:runner().getDisk()});note('Pozícia uložená · '+b.game.title+' · Slot '+$('slot').value);});
$('load').onclick=()=>operation(async()=>{const r=await recordGet(slotKey());if(!r)throw Error('Tento slot je prázdny.');const b=currentBoot;await launch(b.game,b.media,r.bytes,false,r.disk||0);note('Pozícia obnovená.');});
function download(bytes,name,type){const blob=new Blob([bytes],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
$('export').onclick=()=>operation(async()=>{const b=currentBoot,bytes=await runner().save();const payload={format:'atari-game-station-save',version:1,engine:'atari800-495e8125',game:b.game.id,media:b.media,mediaHash:b.game.media[b.media].hash,created:new Date().toISOString(),disk:runner().getDisk(),state:base64(bytes)};download(JSON.stringify(payload),b.game.id+'_'+new Date().toISOString().replace(/[:.]/g,'-')+'.atari-save','application/json');note('Záloha pozície je pripravená na stiahnutie.');});
$('import').onclick=()=>$('import-file').click();
$('import-file').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{if(f.size>5*1024*1024)throw Error('Súbor pozície je príliš veľký.');const data=JSON.parse(await f.text());if(data.format!=='atari-game-station-save'||data.version!==1||data.engine!=='atari800-495e8125')throw Error('Toto nie je kompatibilná pozícia tohto spúšťača.');const g=GAMES.find(g=>g.id===data.game);if(!g)throw Error('Hra z tejto pozície nie je v zbierke.');const mi=g.media.findIndex(m=>m.hash===data.mediaHash);if(mi<0)throw Error('Pozícia pochádza z inej verzie hry.');const disk=data.disk??0;if(!Number.isInteger(disk)||disk<0||disk>(g.media[mi].extraDisks||[]).length)throw Error('Neplatná disketa v pozícii.');const bytes=unbase64(data.state);if(new TextDecoder().decode(bytes.subarray(0,8))!=='ATARI800')throw Error('Poškodené dáta pozície.');
  await launch(g,mi,bytes,false,disk);
  await operation(async()=>{await recordPut({key:slotKey(),created:Date.now(),game:g.id,media:mi,bytes,disk});note('Pozícia načítaná a uložená do vybraného slotu.');});
}catch(e){note('Import: '+e.message,true);}};
let fullscreenPending=false,fullscreenOnStart=true;
function isFullscreen(){return !!(document.fullscreenElement||document.webkitFullscreenElement);}
async function enterFullscreen(silent=false){
  if(isFullscreen())return true;if(fullscreenPending)return false;
  const root=document.documentElement,request=root.requestFullscreen||root.webkitRequestFullscreen;
  if(!request){if(!silent)note('Tento prehliadač nepodporuje Fullscreen.');return false;}
  fullscreenPending=true;
  try{await (root.requestFullscreen?root.requestFullscreen({navigationUI:'hide'}):request.call(root));fullscreenOnStart=false;try{await screen.orientation?.lock('landscape');}catch{}return true;}
  catch{if(!silent)note('Prehliadač nepovolil Fullscreen. Skús ho zapnúť tlačidlom znova.',true);return false;}
  finally{fullscreenPending=false;}
}
$('fullscreen').onclick=async()=>{fullscreenOnStart=false;if(!isFullscreen()){await enterFullscreen();return;}try{await (document.exitFullscreen||document.webkitExitFullscreen).call(document);}catch{note('Fullscreen sa nepodarilo ukončiť.',true);}};
function fullscreenChanged(){const active=isFullscreen();if(!active)fullscreenOnStart=false;$('fullscreen').textContent=active?'⛶ Ukončiť fullscreen':'⛶ Fullscreen';$('fullscreen').setAttribute('aria-pressed',String(active));$('fullscreen').title=active?'Ukončiť celú obrazovku':'Zobraziť na celú obrazovku';releaseAll();}
document.addEventListener('fullscreenchange',fullscreenChanged);document.addEventListener('webkitfullscreenchange',fullscreenChanged);
function showKeyboard(open){releaseAll();$('key-panel').hidden=!open;document.querySelector('.station-shell').classList.toggle('keyboard-open',open);$('keyboard').setAttribute('aria-expanded',String(open));window.getSelection()?.removeAllRanges();}
function openDialog(id){if(!$('key-panel').hidden)showKeyboard(false);releaseAll();$(id).showModal();}
$('keyboard').onclick=()=>showKeyboard($('key-panel').hidden);$('keyboard-close').onclick=()=>showKeyboard(false);$('extra-help').onclick=()=>openDialog('help-dialog');
for(const event of['selectstart','contextmenu','dragstart'])$('key-panel').addEventListener(event,e=>e.preventDefault());
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{b.closest('dialog').close();releaseAll();});document.querySelectorAll('dialog').forEach(d=>d.addEventListener('close',releaseAll));
for(const row of['1234567890','QWERTYUIOP','ASDFGHJKL','ZXCVBNM']){const div=document.createElement('div');div.className='keys';for(const k of row){const b=document.createElement('button');b.textContent=k;b.dataset.key=k;div.append(b);bindKey(b);}$('key-rows').append(div);}document.querySelectorAll('#key-panel [data-key]').forEach(b=>{if(!b.closest('#key-rows'))bindKey(b);});
$('turbo').onclick=async()=>{if(!ready)return;await runner().pulse('turbo');turbo=!turbo;$('turbo').textContent='Turbo: '+(turbo?'zap.':'vyp.');};
$('native-menu').onclick=async()=>{if(!ready)return;await runner().pulse('menu');$('help-dialog').close();note('Menu: použi Klávesnicu, kurzorové šípky, RETURN a ESC.');};$('native-return').onclick=async()=>{if(!ready)return;await runner().pulse('escape');$('help-dialog').close();};
$('original-boot').onclick=()=>{$('help-dialog').close();start();};
$('quick-boot').onclick=()=>{const g=selected(),mi=Number($('media').value||0);if(!g.media[mi].boot){note('Táto verzia nemá pripravený rýchly štart. Použi Spustiť hru.');return;}$('help-dialog').close();if(fullscreenOnStart){fullscreenOnStart=false;enterFullscreen(true);}launch(g,mi,null,true).catch(e=>note(e.message,true));};
$('source-download').onclick=async()=>{try{download(await asset('source'),'Atari_Game_Station_zdroje.tar.gz','application/gzip');}catch(e){note(e.message,true);}};
renderKeys(selected());
// Browsers that allow fullscreen on opening can enter immediately. Otherwise
// start() retries synchronously in the first launch gesture, before any await.
enterFullscreen(true);

function updateDiskSelector(m){const s=$('disk-select');s.replaceChildren();s.hidden=!(m.extraDisks?.length);if(s.hidden)return;[m,...m.extraDisks].forEach((d,i)=>{const o=document.createElement('option');o.value=i;o.textContent='D1: '+d.name;s.append(o);});s.value='0';s.disabled=true;}
$('disk-select').onchange=()=>operation(async()=>{await runner().swapDisk(Number($('disk-select').value));note('Disketa v D1 bola vymenená.');});
