# Atari Game Station — offline HTML

Samostatný spúšťač dodaných zbierok Games.zip a Games2.zip. Pôvodný Games.zip má SHA-256
4d2d3c5404a59d53bb38202ce2da9d5c4b6f5e6a1d4a97b7f660c9ca8c1d07e2.
Všetky herné médiá sú v games.json vrátane pôvodných ATX a oboch strán Misja/Fred.

## Jadro a súbory

- Atari800 fork: https://github.com/Retro-Jack/atari800
  commit 495e8125502fec7bf3c3f667ccea7c4bcc7fc7f4; celý zdroj je v atari800/.
- Predkompilovaný runtime z https://github.com/Retro-Jack/GenX-DOS,
  commit 44e7aa5e3e91a99a16a302877b05abab8e5cb51d; runtime/atari800.js a .wasm.
- Firmware je z nezmeneného PC Xformer Classic 3.8: firmware/pcxf380.zip.
  MD5 0225dc8bcf2e69fd30c12a226822222a. Oficiálny projekt Atari800 tento balík
  odkazuje na https://atari800.github.io/download.html.
  Zdrojová URL http://www.emulators.com/freefile/pcxf380.zip;
  rovnaký súbor bol získaný z https://distfiles.macports.org/atari800/pcxf380.zip.
- Atari800 a jeho úpravy: GPL-2.0-or-later, pozri atari800/COPYING.
  Vlastný kód tohto spúšťača: GPL-2.0-or-later. Herné dáta a firmware týmto
  nemenia licenciu; zostávajú majetkom pôvodných držiteľov práv.

## Podstatné implementačné pravidlá

1. Každá nová hra beží v novom srcdoc iframe; odstránenie starého rámca zastaví
   jeho emulátor. Všetky dáta sú inline a na beh netreba sieť ani server.
2. SDL2 musí dostať canvas s id="canvas", inak vracia nulový rozmer textúry.
   Iframe má trvalo 384×288; na veľkosť obrazovky sa škáluje celý iframe.
   Zmena natívnej SDL veľkosti pri otočení mobilu viedla k orezaniu obrazu.
3. Použité sú originálne XL/XE a OS-B ROM. AltirraOS nestačil Universal Hero.
4. CAS a ATX v tejto zbierke potrebujú -nopatch. SIO patch môže pokaziť loader
   alebo kontrolu diskety (napr. Karateka). ATR/COM/cartridge zostávajú s patchom.
5. Bežné Spustiť hru používa pôvodné načítanie a celý úvod. Voliteľný
   Rýchly štart bez úvodu v Návode používa gzip snímku media.boot vytvorenú
   po nahratí pôvodnej hry; môže preskočiť intro alebo začiatok hrania. Uloženie kazetovej operácie počas
   načítania nie je v Atari800 podporované; úvodné snímky overiť po obnovení.
6. Save/load volať len cez _gx_request_save/_gx_request_load a počkať na
   _gx_state_status. Priame volanie StateSav z JS poškodí ASYNCIFY zásobník.
   Atari800 5.2 StateSav_SaveFNAME pri cwd="/" zmení /game.atx na ame.atx.
   To po obnovení znemožní ďalšie čítanie diskety. Pred spustením nastavujeme
   cwd na /home/web_user a ponechávame aliasy ame.ext pre staršie úvodné snímky.
7. Zvukový kontext je Module.SDL2.audioContext, nie globálny SDL2.
8. Vstupy evidujú jednotlivé zdroje; joystick, akcia a klávesnica sa nesmú
   navzájom uvoľňovať. Uvoľniť vstupy pri skrytí, strate fokusu a výmene hry.
9. IndexedDB ukladá dokončenou transakciou, samostatne podľa ID hry, SHA-256
   média a čísla slotu. Export obsahuje identitu jadra, média a celý stav.
10. Pri testovaní v obmedzenom headless prostredí bolo potrebné v testovacom
    skripte vypnúť detekciu fyzických gamepadov, pretože systém blokuje udev
    sockety. Toto obmedzenie nie je v dodanom spúšťači.

## Overenie

Testované z file:// s blokovanou sieťou: reálne vykresľovanie, nenulový zvukový
výstup, mute, snapshot save/load, päť oddelených slotov, opätovné otvorenie HTML,
export/import s automatickým prepnutím hry, dva súčasné dotyky a diagonály,
fyzická klávesnica, Fullscreen API a rozloženia 1280×800, 1920×1080, 844×393,
915×412, 740×360, 393×844 a 360×780. Mobilné FPS na fyzickom telefóne neboli merané.

## Obnovenie zostavenia

Súbory launcher/ sú čitateľné zdroje hostiteľa. Z koreňa rozbaleného archívu spusti `python3 launcher/build.py`.
V priečinku output/ vznikne nové samostatné HTML aj archív zdrojov. Natívne jadro sa dá
zostaviť podľa atari800/BUILDING-WASM.md. Pri úprave UI nie je potrebné
prekladať natívne jadro ani meniť herné dáta.

## Rozloženie po úprave podľa snímky používateľa

Na šírku je obrazovka samostatný stredný panel cez takmer celú výšku okna.
Výbery HRA/verzia sú pod sebou naľavo, pod joystickom je Slot/Uložiť/Načítať.
Napravo sú Klávesnica/Fullscreen, Návod/menu, herné klávesy, FIRE a export/import.
Tlačidlo Zvuk bolo odstránené; zvuk zostáva aktívny. Pevný iframe 384×288
sa škáluje v oboch osiach na rozmery panelu podľa požadovaného červeného rámika.
Počas zmeny orientácie sa nemení vnútorná veľkosť SDL. Herné dáta, jadro,
BIOS, runner a úvodné snímky zostali oproti predchádzajúcej verzii byte-identické.
Overené bez siete: geometria bez prekrývania pri 1536×691, 1280×800, 1920×1080,
844×393, 915×412, 740×360, 393×844 a 360×780; skutočný štart, zvuk, save/load,
export/import, trvalé sloty, dva dotyky, fyzická klávesnica a Fullscreen.

## Oprava odozvy ovládania

Pri dotykoch sa v Chromium odkladali krátke setTimeout pokračovania natívneho
emscripten_sleep. Samotný KeyboardEvent sa odoslal za menej než 1 ms, ale emulácia
čakala na naplánované pokračovanie. Izolované vypnutie opakovaného audio resume
ani postTask s user-blocking prioritou toto odkladanie neodstránili.

Runner preto pred vložením pripnutého Emscripten JS nahrádza jediný známy riadok
emscripten_sleep hookom Module.frameSleep. Pôvodný timer beží súbežne s kontrolou
termínu v requestAnimationFrame rodičovského okna. Skoršia úspešná vetva zruší
druhú; kontrola finished garantuje jediné pokračovanie ASYNCIFY. Hook nebudí
CPU pred uplynutím požadovaného oneskorenia a nemení PAL rýchlosť hry. Pri skrytej
stránke zostáva pôvodný timer. Všeobecné časovače stránky sa nemenia.

Zvuk sa obnovuje len zo stavu suspended/interrupted. Bežiaci AudioContext sa pri
každom dotyku znovu neštartuje. Vstup sa odošle pred prípadným odomknutím zvuku.
Klávesové mapovanie, natívny WASM, hry, BIOS, úvodné pozície a formát záloh
zostávajú nezmenené a sú kompatibilné s predchádzajúcimi exportmi.

Meranie v headless Chromium, 844×393, Bruce Lee, skutočné CDP dotyky: pôvodná
verzia pri 12 stlačeniach FIRE mala najväčšiu prestávku medzi vykresleniami
567,9 ms a 13 prestávok nad 50 ms; opravená verzia 33,6 ms a žiadnu nad 50 ms.
Pri joysticku sa maximum znížilo z 374,4 na 37,1 ms (10 → 0 prestávok nad 50 ms).
Meranie nie je výsledkom na fyzickom Xiaomi. Prešla aj kontrola zvuku, snapshotov,
trvalých slotov, exportu/importu, rozloženia, dvoch dotykov a Fullscreen.

## Rozšírenie Games2.zip

Games2.zip má SHA-256
2250ea4d4c792ba21ece3f5234e17b9156aae1e8bcd8c59ce22f466e3cf1112d.
Obsahuje 42 vnorených ZIP archívov a 48 pôvodných herných médií. Všetkých 48
médií je v balíku bez zmeny obsahu (overené SHA-256). Pridaných je 42 položiek,
spolu 58 titulov; pôvodných 16 položiek games.json zostalo nezmenených.
Easy Money a Honky sú samostatné položky. Strip Poker Data Disk 1 je doplnková
disketa Strip Poker, nie samostatná hra.

Dodaný súbor označený Last Ninja II je v skutočnosti Art Gallery System V3.1
s obrázkami. V menu je preto označený „Last Ninja II — galéria obrázkov“.
Neobsahuje hrateľnú verziu Last Ninja II.

- CAR/ROM s hlavičkou CART používajú typ z hlavičky; surové 8/16/32/64 KB
  cartridge majú explicitný typ 1/2/12/13. Mario Bros je CART aj s príponou ROM.
- Súbory BAS sa spúšťajú s BASIC. Strip Poker tiež potrebuje -basic.
  IK RC/RCX majú rozšírenú RAM -rambo (320 KB).
- Všetkých 42 nových hlavných médií má overenú úvodnú snímku. CAS Ninja,
  Ninja Commando a Spiky Harold boli nahraté do konca pred vytvorením snímky.
  Ninja má po rýchlom štarte jednorazové FIRE na zrušenie úvodnej pauzy;
  toto sa neodosiela pri načítaní používateľovej pozície.
- PacMan Labyrinth potrebuje prejsť úvodné INIT obrazovky klávesom START,
  aby sa dokončilo načítanie XEX. Snímka vznikla až po uzavretí vstupného
  súboru a bola obnovená priamo do hrateľného bludiska.
- Pri obnove úvodnej alebo používateľovej snímky sa najskôr spustí holý
  počítač, bez nového loadera herného súboru. Obnovujúca snímka sama nastaví
  diskety/cartridge a CPU; paralelný nový BINLOAD by mohol narušiť stav.
- Doplnený je SDL2 keypress pre písmená a čísla virtuálnej klávesnice.
  Joystickové klávesy nevytvárajú text. One on One reálne prijal výber
  joysticku 1 a RETURN a pokračoval do hry.
- Strip Poker má v D2 priloženú doplnkovú disketu a výber média v D1.
  Výmena v D1 používa uloženie/obnovenie CPU a natívne znovupripojenie diskety.
  Voľba 4 OTHER + doplnková D1 + FIRE zobrazila súperky MARLENA/CANDI.
  Sloty aj export/import obsahujú voliteľné číslo diskety; staršie zálohy
  bez neho používajú základnú disketu 0.

Záverečný beh bez siete: všetkých 42 nových položiek prešlo rýchlym štartom,
odovzdaním START/FIRE a natívnym uložením/obnovením stavu, bez JS chýb.
Herné scény boli vizuálne skontrolované; nejde o prejdenie všetkých levelov.
Samostatne prešiel výber disku Strip Poker, uloženie, export aj import jeho
pozície s disketou. Regresná kontrola potvrdila nenulový zvuk, pretrvanie slotu,
export/import s prepnutím hry, osem rozmerov obrazovky, dva súčasné dotyky,
fyzickú klávesnicu a fullscreen. Oprava odozvy frameSleep zostala zachovaná.

## Prepínateľné ovládanie Analóg / D-pad

Vedľa Spustiť hru je prepínač Analóg / D-pad. Zmena ovládača uvoľní všetky
vstupy a nemení bežiaci emulátor ani pozíciu hry. Režim sa ukladá do localStorage;
pri nedostupnom úložisku prepínanie ďalej funguje bez zapamätania.

D-pad má osem smerových polí a neutrálny stred. Pointer capture umožňuje
prechádzať prstom medzi smermi; mimo plochy sa smer uvoľní. Každý prst má
samostatný zdroj vstupov, takže uvoľnenie jedného prsta nezruší druhý.
FIRE môže byť držaný súčasne. Cancel, blur, skrytie stránky aj prepnutie
režimu uvoľnia vstupy. Analóg má zosilnenie polohy 0,9 oproti predchádzajúcej
verzii, teda o 10 % menšiu citlivosť; prahy smerov a mŕtvej zóny sa nemenia.

Overené skutočnými CDP dotykmi: všetkých osem smerov, neutrálny stred,
posúvanie a vyjdenie mimo D-padu spolu s FIRE, dva prsty a oddelené uvoľnenie,
pointercancel, prepnutie počas držania a zapamätanie režimu po reload.
Pre analóg overený prah: posun 0,35 pôvodného polomeru ostáva neutrálny,
0,38 už aktivuje smer. Oba režimy prešli kontrolou geometrie pri rozmeroch
1536×691, 1280×800, 1920×1080, 844×393, 915×412, 740×360, 393×844 a 360×780.
Regresná kontrola overila zvuk, save/load, export/import, trvalé sloty,
fyzickú klávesnicu, súčasný joystick/FIRE a fullscreen. Herné dáta a runner
s opravou odozvy sa v tejto úprave nemenili.

## AUTO FIRE

Pod tlačidlom FIRE je samostatné prepínacie AUTO FIRE. Zapnutý stav je zelený,
textový a má aria-pressed=true. Opakuje 8 stlačení za sekundu s rovnakou dĺžkou
stlačenia a uvoľnenia 62,5 ms. Fázu riadi requestAnimationFrame; pri oneskorenom
vykreslení sa neodosiela séria oneskorených udalostí naraz. Používa samostatný
zdroj vstupu auto-fire, takže nestráca ručne držané FIRE a neovplyvňuje smery.

Všetky existujúce releaseAll udalosti automatickú streľbu vypnú: výmena hry,
menu, klávesnica, save/load/export/import, zmena ovládania, strata fokusu,
skrytie stránky a zmena fullscreen. Po vypnutí nezostáva bežať časovač ani rAF.
Nastavenie sa neukladá medzi reláciami ani nepridáva do herných snapshotov.

Overené bez siete v Chromium: 8 Hz pulzy, zapnutie/vypnutie bez zostávajúcich
vstupov, zachovanie fyzicky držaného FIRE, analógové aj D-pad diagonály počas
streľby, zastavenie pri save/load, menu, blur a výmene hry. Tlačidlo zostáva pod
FIRE v ôsmich rozmeroch vrátane 740×360 a 360×780 bez prekrývania. Prešli aj
regresné kontroly zvuku, trvalých slotov, exportu/importu, súčasných dotykov,
fyzickej klávesnice a fullscreen. Hry, jadro a runner zostali nezmenené.

## Zvýraznený a automatický Fullscreen

Tlačidlo Fullscreen má výrazné modré pozadie, svetlý dvojpixelový rámik,
symbol celej obrazovky a pri aktivácii zelený stav. aria-pressed a text sa
aktualizujú aj pri vonkajšej zmene Fullscreen API. Zachovaný je veľký stredový
panel a všetky herné ovládače.

Pri otvorení HTML sa vykoná jeden tichý pokus o fullscreen. Pri zablokovaní
sa nezobrazí chyba ani sa nepreruší hranie. Prvé používateľské stlačenie
Spustiť hru skúsi fullscreen znovu, priamo v synchronnej časti click handlera
pred asynchrónnym načítaním emulátora, aby zostala platná user activation.
Po ručnom ukončení sa ďalšie spustenie hry do fullscreenu samo nevracia.
Pri štandardnom API sa žiada navigationUI=hide a potom orientácia landscape;
nepodporované uzamknutie orientácie sa ignoruje. Legacy WebKit API je
podporované cez webkitRequestFullscreen/webkitExitFullscreen a príslušnú
udalosť. Ak API chýba, hra beží ďalej v bežnom okne.

Overené v Chromium bez siete: blokovaný pokus pri otvorení bez aktivácie,
úspešný fullscreen pri prvom kliknutí na cover-start (v momente requestu
navigator.userActivation.isActive=true), návrat do okna, rešpektovanie ručného
ukončenia pri ďalšom štarte a opätovné ručné zapnutie. Samostatný test s
vynúteným zamietnutím API potvrdil spustenie hry bez chyby a vysvetlenie až
po priamom stlačení Fullscreen. Prešli aj zvuk, save/load, export/import,
trvalé sloty, osem rozmerov obrazovky, multitouch, klávesnica a fullscreen.
Herné dáta a runtime zostali nezmenené.

## Rozšírenie Games3.zip

SHA-256 dodaného archívu:
85bceb439e90a716bffe3103388945adf99a382d46d604201abd83801725f663.
Pridaných je 18 titulov z 18 vnorených ZIP archívov, spolu 76 titulov.
Balík obsahuje všetkých 28 dodaných herných médií aj textové poznámky Prince
of Persia. Pôvodných 58 položiek games.json zostalo byte-identických.
Nové dáta majú overené SHA-256 voči vnoreným archívom. Súbory __MACOSX nie sú
herné médiá a neboli pridané.

Prince of Persia a Dizzy potrebujú aspoň 128 KB RAM; sú nastavené na Rambo
320 KB. Prince ponúka MegaCart (predvolené), AtariMax, SIC!, DD a SD diskety.
SD strana B a druhá strana Space Trouble II sú pripojené ako extraDisks;
D1 sa mení pri výzve hry. Pri Prince SD sa počas úvodu objaví Insert other disk;
vyber v D1 stranu B a pokračuj. Preferovaný MegaCart výmenu diskiet nepotrebuje.
Silent Service má vlastné tlačidlá 1/2/3, START, OPTION a RETURN.

Dodaný Robbo side B nezačína spustiteľným kazetovým zavádzačom a samostatný
pokus skončil v teste pamäte. Skúšobné doplnenie zavádzača zo strany A to
nevyriešilo a nebolo zahrnuté. Strana B zostala úplne nezmenená v games.json,
ale je v menu označená ako nespustiteľná samostatne a voľba je neaktívna.
Robbo zo strany A bolo reálne spustené do herného bludiska. Takto sa používateľovi
neponúka neoverená alebo nefunkčná úvodná snímka.

Pre 25 spustiteľných mediálnych volieb boli vytvorené úvodné snímky a overený
nový štart emulátora so snímkou aj následné natívne save/load. Pri Zeppelin COM,
Zorro ATX a Silent Service ATX bolo nutné počkať aj na dokončenie prechodu
z titulnej obrazovky do hry/menu. Príliš skoré snímky počas načítania sa
nepoužívajú. Dizzy XEX bol uložený až po uzavretí loadera. Prince bol overený
v hrateľnej prvej úrovni. Pri Arkanoid je vizuálne potvrdený pohyb pálky
na obidve strany; Silent Service prijalo číselný výber cez tlačidlá.
Space Trouble II prešlo výmenou média v D1 a obnovením zvolenej strany zo slotu.
Ide o overenie štartu, základného ovládania a stavov, nie o prejdenie všetkých
úrovní. Alternatívne diskové vydania môžu ďalej vyžadovať čakanie alebo výmenu
strany podľa výzvy pôvodnej hry.

Ovládače Analóg/D-pad, znížená citlivosť analógu, AUTO FIRE, zvýraznený
Fullscreen a automatický pokus pri otvorení/prvom spustení zostali zachované.
Natívny runtime, ROM a časovací hook frameSleep sa nemenili.

Záverečný beh všetkých 18 nových predvolených titulov prešiel štartom,
smerovým vstupom a natívnym save/load bez JS chýb. Regresný beh potvrdil
nenulový zvuk, export/import, trvalé sloty, osem rozmerov, súčasné dotyky,
klávesnicu a fullscreen. Overená bola aj výmena Prince SD D1 a obnova strany zo slotu.

## Klávesnica v pravom paneli a súčasný ovládač vľavo

Virtuálna klávesnica už nie je modálny dialog. Sekcia key-panel je priamo
v pravom paneli namiesto bežných herných tlačidiel a exportu/importu; horné
Klávesnica/Fullscreen zostávajú dostupné. Herná obrazovka zostáva viditeľná
medzi klávesnicou a ľavým ovládačom. Vľavo sa dá stále prepínať Analóg/D-pad.
Keďže nič nie je inert ani prekryté modálnym backdrop, smer a klávesy možno
držať naraz. V pravom paneli sú aj FIRE, START/SELECT/OPTION a kurzorové šípky.
SHIFT a CTRL zostali prepínačmi; zatvorenie uvoľní všetky vstupy.

Celý panel vrátane nadpisu má user-select:none, -webkit-user-select:none,
-webkit-touch-callout:none; selectstart/contextmenu/dragstart sa rušia iba
v klávesnici. Písmená v užšom paneli sa zalamujú do piatich stĺpcov a posúvajú
zvisle v samostatnej oblasti. Funkčné tlačidlá zostávajú pevne dolu.
Na výšku je klávesnica v rovnakom pravom stĺpci ako pôvodné herné klávesy,
s troma stĺpcami písmen a dvoma stĺpcami funkcií. Po zavretí sa vrátia
pôvodné herné ovládacie tlačidlá aj export/import.

Overené bez siete v Chromium: osem rozmerov 1536×691 až 360×780; pravý panel
nepresahuje cez hernú obrazovku, ľavý joystick zostáva vľavo, bez horizontálneho
pretekaniu alebo modálneho dialógu. Myšou sa nepodarilo označiť nadpis a
contextmenu sa zrušilo. Skutočné dva CDP dotyky overili diagonálu analógu aj
D-padu súčasne s FIRE na klávesnici; uvoľnenie klávesu zachovalo smer a po
uvoľnení oboch nezostal vstup. Overené SHIFT, posun na Q a uvoľnenie pri zavretí.
One on One prijalo 1 + RETURN z pravého panela a vykreslilo herné ihrisko.
Regresný beh potvrdil zvuk, save/load, trvalé sloty, export/import, rozloženie,
multitouch, fyzickú klávesnicu a fullscreen. Herné dáta a runner sa nemenili.

## Odstránenie duplicitnej Karateky a zachovanie pôvodného úvodu

Na výslovnú žiadosť používateľa bola odstránená položka Karateka
(Karateka_Broderbund_Software, Karateka.atx) aj jej médium a rýchla snímka.
Karateka (cartridge), ID Karateka_Atari_USA, zostala. Zbierka má 75 titulov;
všetkých 75 ponechaných objektov games.json zostalo nezmenených.

Príčinou preskočenia intra bol automatický štart z pripravenej snímky, ktorá
bola pri niektorých hrách vytvorená až po START/FIRE alebo počas hrania.
bootGame má teraz useQuick=false ako predvolenú hodnotu. Bežné Spustiť hru
aj tlačidlo na úvodnom kryte štartujú pôvodné médium od resetu, bez obnovenia
media.boot a bez bootKeys. Pôvodný úvod sa tak zobrazí aj v Prince of Persia
či Karateka (cartridge). Pri kazetách/disketách treba počkať na pôvodné nahratie.
Pripravené snímky zostávajú dostupné iba po výslovnom stlačení Rýchly štart
bez úvodu v Návode. Voľba je vysvetlená v rozhraní a funguje aj pred prvým
spustením hry alebo po zmene výberu v zozname.

Sloty a import obnovujú presnú používateľskú pozíciu v novom srcdoc emulátore,
ktorý pred obnovou nespúšťa ďalší loader. Tým sa predíde súbežnému BINLOAD alebo
kazetovému načítaniu z práve otvorenej hry. Číslo D1 sa odovzdá pri obnove
priamo do runner.load; formát starších exportov a identifikátory médií sa nemenia.
Zámok busy zostáva aktívny po celý čas obnovovania slotu.

Overené bez siete v Chromium: odstránená presne označená disková Karateka,
ponechaná cartridge a počet 75; UI spustenie Prince a Karateka cartridge má
restoreAtBoot=false a natívne -cart /game.car, nevysiela START/FIRE a vizuálne
zobrazí pôvodný úvod (Prince – animácia s Atari logom, Karateka – titulná
obrazovka). Samostatne overený výslovný rýchly štart, uloženie slotu, nový štart
od úvodu a obnova slotu aj import tej istej hry do holého nového emulátora.
Manic Miner potvrdil predvolený pôvodný štart aj pre XEX. Regresný test prešiel
zvukom, trvalými slotmi, exportom/importom, ôsmimi rozmermi obrazovky,
súčasnými dotykmi, klávesnicou a fullscreen. Native runtime, časovanie vstupov,
klávesnica vpravo, D-pad a AUTO FIRE sa nemenili.
