from pathlib import Path
import json,base64,gzip,subprocess,tarfile,io,hashlib,zipfile
root=Path(__file__).resolve().parent.parent
w=root/'work' if (root/'work').exists() else root/'launcher'
core=root/'vendor/genx/systems/atari800' if (root/'vendor/genx').exists() else root/'runtime'
firmware=w/'pcxf380-mirror.zip' if (w/'pcxf380-mirror.zip').exists() else root/'firmware/pcxf380.zip'
(root/'output').mkdir(exist_ok=True)
def b64(b):return base64.b64encode(b).decode()
def asset(name,data,compressed=True):
    return '<script id="asset-'+name+'" type="application/octet-stream" data-gzip="'+('1' if compressed else '0')+'">'+b64(gzip.compress(data,mtime=0) if compressed else data)+'</script>'
if (root/'vendor/atari800/.git').exists():
    source=subprocess.check_output(['git','-C',str(root/'vendor/atari800'),'archive','--format=tar','--prefix=atari800/','HEAD'])
else:
    native=io.BytesIO()
    with tarfile.open(fileobj=native,mode='w') as t:
        t.add(root/'atari800',arcname='atari800')
    source=native.getvalue()
stream=io.BytesIO(source)
with tarfile.open(fileobj=stream,mode='a') as tar:
    for path,name in [
        (w/'app.js','launcher/app.js'),(w/'runner.js','launcher/runner.js'),
        (w/'shell.html','launcher/shell.html'),(w/'games.json','launcher/games.json'),
        (w/'README_SK.md','launcher/README_SK.md'),(w/'build.py','launcher/build.py'),
        (firmware,'firmware/pcxf380.zip'),
        (core/'atari800.js','runtime/atari800.js'),
        (core/'atari800.wasm','runtime/atari800.wasm')]:
        if path.exists():
            data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(w/'source.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
payload='\n'.join([
asset('bios',json.dumps({n.lower():b64(zipfile.ZipFile(firmware).read(n)) for n in ['ATARIOSB.ROM','ATARIBAS.ROM','ATARIXL.ROM']}).encode()),
asset('core-js',(core/'atari800.js').read_bytes()),
asset('core-wasm',(core/'atari800.wasm').read_bytes()),
asset('runner',(w/'runner.js').read_bytes()),
asset('source',(w/'source.tar.gz').read_bytes(),False),
'<script id="game-data" type="application/json">'+(w/'games.json').read_text().replace('</','<\\/')+'</script>'
])
html=(w/'shell.html').read_text().replace('@@ASSETS@@',payload).replace('@@APP@@',(w/'app.js').read_text())
out=root/'output/Atari_Game_Station_OFFLINE.html';out.write_text(html)
(root/'output/Atari_Game_Station_zdroje.tar.gz').write_bytes((w/'source.tar.gz').read_bytes())
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
